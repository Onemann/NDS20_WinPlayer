﻿using System;

namespace NDS20WinPlayer
{
    public struct frameInfoStrc
    {
        public int xPos;
        public int yPos;
    }

}